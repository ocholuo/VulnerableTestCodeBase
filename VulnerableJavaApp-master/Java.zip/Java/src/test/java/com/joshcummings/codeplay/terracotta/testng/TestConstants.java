package com.joshcummings.codeplay.terracotta.testng;

public class TestConstants {
	public static final String host = "honestsite.com";
	public static final String evilHost = "evilsite.com";
}
